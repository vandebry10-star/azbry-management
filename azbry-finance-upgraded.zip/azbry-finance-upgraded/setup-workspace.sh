#!/bin/bash
# ══════════════════════════════════════
#  AZBRY FINANCE — Git Workspace Setup
#  Jalankan di Termius / terminal HP
#  Usage: bash setup-workspace.sh
# ══════════════════════════════════════

set -e

# ── CONFIG (edit sesuai kebutuhan) ──
REPO_NAME="azbry-management"
GITHUB_USER="vandebry10"          # ganti dengan username GitHub kamu
GITHUB_EMAIL="your@email.com"     # ganti dengan email GitHub kamu
ZIP_FILE="azbry-management.zip"   # nama file zip yang diupload

echo ""
echo "╔══════════════════════════════════╗"
echo "║   Azbry Finance Workspace Setup  ║"
echo "╚══════════════════════════════════╝"
echo ""

# ── 1. CEK DEPENDENCIES ──
echo "► Mengecek dependencies..."

if ! command -v git &>/dev/null; then
  echo "  git tidak ditemukan, install..."
  apt-get install -y git 2>/dev/null || pkg install git -y 2>/dev/null || true
fi

if ! command -v unzip &>/dev/null; then
  echo "  unzip tidak ditemukan, install..."
  apt-get install -y unzip 2>/dev/null || pkg install unzip -y 2>/dev/null || true
fi

echo "  ✓ Dependencies OK"
echo ""

# ── 2. UNZIP PROJECT ──
if [ -f "$ZIP_FILE" ]; then
  echo "► Mengekstrak $ZIP_FILE..."
  
  # Buat folder sementara untuk ekstrak
  mkdir -p _zip_temp
  unzip -o "$ZIP_FILE" -d _zip_temp
  
  # Cari folder hasil ekstrak
  EXTRACTED=$(find _zip_temp -maxdepth 1 -mindepth 1 -type d | head -1)
  
  if [ -z "$EXTRACTED" ]; then
    echo "  ✗ Gagal menemukan folder dalam zip"
    exit 1
  fi
  
  echo "  ✓ Diekstrak ke: $EXTRACTED"
  
  # Pindahkan isi ke folder repo
  mkdir -p "$REPO_NAME"
  cp -r "$EXTRACTED"/. "$REPO_NAME"/
  rm -rf _zip_temp
  
  echo "  ✓ File dipindahkan ke folder $REPO_NAME"
else
  echo "  ⚠ File $ZIP_FILE tidak ditemukan"
  echo "  Asumsikan folder $REPO_NAME sudah ada..."
  
  if [ ! -d "$REPO_NAME" ]; then
    mkdir -p "$REPO_NAME"
    echo "  ✓ Folder $REPO_NAME dibuat (kosong)"
  fi
fi

echo ""

# ── 3. MASUK KE FOLDER ──
cd "$REPO_NAME"
echo "► Direktori sekarang: $(pwd)"
echo ""

# ── 4. GIT INIT ──
if [ ! -d ".git" ]; then
  echo "► Inisialisasi Git repository..."
  git init
  git branch -M main
  echo "  ✓ Git init selesai"
else
  echo "► Git repo sudah ada, skip init"
fi
echo ""

# ── 5. GIT CONFIG ──
echo "► Setup Git config..."
git config user.name "$GITHUB_USER"
git config user.email "$GITHUB_EMAIL"
echo "  ✓ Git config set: $GITHUB_USER <$GITHUB_EMAIL>"
echo ""

# ── 6. BUAT .gitignore KALAU BELUM ADA ──
if [ ! -f ".gitignore" ]; then
  cat > .gitignore << 'EOF'
.DS_Store
node_modules/
.env
.env.local
*.log
.vercel
_zip_temp/
EOF
  echo "► .gitignore dibuat"
fi

# ── 7. FIRST COMMIT ──
echo "► Staging semua file..."
git add -A
echo ""
echo "► Commit pertama..."
git commit -m "feat: initial upload - Azbry Finance upgraded UI" 2>/dev/null || echo "  (tidak ada perubahan baru untuk di-commit)"
echo ""

# ── 8. PANDUAN PUSH KE GITHUB ──
echo "╔══════════════════════════════════════════╗"
echo "║         LANGKAH SELANJUTNYA              ║"
echo "╠══════════════════════════════════════════╣"
echo "║                                          ║"
echo "║  1. Buat repo baru di GitHub:            ║"
echo "║     github.com/new                       ║"
echo "║     Nama: $REPO_NAME"
echo "║     Jangan centang README/gitignore      ║"
echo "║                                          ║"
echo "║  2. Hubungkan ke remote & push:          ║"
echo "║                                          ║"
echo "║  git remote add origin \\                 ║"
echo "║    https://github.com/$GITHUB_USER/$REPO_NAME.git"
echo "║  git push -u origin main                 ║"
echo "║                                          ║"
echo "║  3. Deploy ke Vercel:                    ║"
echo "║     vercel.com → New Project             ║"
echo "║     Import repo → Framework: Other       ║"
echo "║     → Deploy ✓                          ║"
echo "║                                          ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "✓ Setup selesai! Folder: $(pwd)"
echo ""
